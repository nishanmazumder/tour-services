
<title>Rates - Taxi Moutiers Transfert - Transfers - Savoy, France.</title>
<style type="text/css">
.centrer {
	text-align: center;
}
body {
	margin-top: 20px;
	background-image: url(../images/body-fond.jpg);
	background-color: #000;
	background-repeat: no-repeat;
}
h1 {
	font-size: 20px;
}
h3 {
	font-size: 15px;
}
body,td,th {
	color: #333;
}
.centrer tr td centrer plu {
	text-align: center;
}
</style>
</head>

<body>
<table class="table table-bordered table-striped">
  <tr>
    <td bgcolor="#FFFFFF"><a href="booking.php" target="_blank"><img src="../images/bandeau.jpg" alt="Taxi Moutiers - Transfert taxi Moutiers Courchevel, Meribel, Val Thorens" name="logo" width="980" height="320" /></a></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF"><h1>TAXI MOUTIERS TRANSFERT RATES :</h1></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF"><?php include("../admin/data/blocks/tarifs-anglais.html"); ?></td>
  </tr>
</table>
</body>
</html>