<?php /* Copyright PulseCMS.com. All rights reserved. */ ?>
<li <?php if ($on=="settings") echo " class=\"on\""; ?>>
	<a href="index.php?p=settings"><?php echo $lang_nav_settings; ?></a>
</li>