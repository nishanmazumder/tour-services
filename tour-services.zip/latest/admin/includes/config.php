<?php    
$pulse_dir = "admin";
$pulse_pass = "taximout73";
$slider_style = false;
$blog_url = "http://example.com/blog.php";
$per_page = "5";
$blog_title = "My Blog Name";
$rewrite = false;
$blog_description = "My blog description";
$blog_comments = true;
$questions["What color is the ocean?"] = "blue";
$questions["What is the year after this one?"] = "2013";
$questions["How many letters in the word MARKET?"] = "6";
$date_format = "0";
$settings_page = true;
$email_contact = "your email";
$pulse_lang = "0";
?>