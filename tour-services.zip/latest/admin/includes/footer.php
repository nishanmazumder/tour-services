</div>

<div id="footer">

<a class="ver" target="_blank" href="http://pulsecms.com/download.php">Pulse Pro 1.8.2</a>
<a class="help" target="_blank" href="http://pulsecms.com/support.php">Help</a>

</div>

</body>

</html>